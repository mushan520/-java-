/**
 * 
 */
/**
 * @author 59499
 *
 */
module 分数 {
}